Playing radio station from the globe from terminal 

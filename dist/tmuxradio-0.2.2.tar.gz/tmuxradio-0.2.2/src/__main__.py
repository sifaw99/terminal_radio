from welcome import main

def start():
	if __name__=="__main__":
		main()
